import { supabase } from "./supabase.js";
import { BUCKET } from "./config.js";
import { S, getProfile } from "./state.js";
import { avatar, go, h, toast, topbar, viewer } from "./ui.js";
import { icon } from "./icons.js";
import { ago, compressImage, safeUrl } from "./utils.js";

const hhmm = (d) => new Date(d).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
function dayLabel(d) {
  const x = new Date(d), t = new Date();
  const diff = Math.round((new Date(t.getFullYear(), t.getMonth(), t.getDate()) - new Date(x.getFullYear(), x.getMonth(), x.getDate())) / 86400000);
  return diff === 0 ? "Hoje" : diff === 1 ? "Ontem" : x.toLocaleDateString("pt-BR", { day: "2-digit", month: "long" });
}

export async function chatsScreen(box) {
  const me = S.user.id;
  const dms = h("div", {}, h("p", { class: "empty" }, "Carregando..."));
  box.append(h("div", { class: "screen" }, topbar("Conversas"),
    h("div", { class: "row cityrow", onclick: () => go("/city") },
      h("div", { class: "av", style: "width:44px;height:44px;background:rgba(255,255,255,.25)" }, icon("chat", 22)),
      h("div", { class: "g" }, h("b", {}, "Chat de " + S.me.city_name), h("small", {}, "Público · todo mundo da cidade"))),
    h("div", { class: "sec" }, "Conversas privadas"), dms));
  const { data } = await supabase.from("cx_messages").select("*").not("recipient_id", "is", null).order("created_at", { ascending: false }).limit(200);
  const last = new Map();
  for (const m of data || []) { const o = m.sender_id === me ? m.recipient_id : m.sender_id; if (!last.has(o)) last.set(o, m); }
  if (!last.size) { dms.replaceChildren(h("p", { class: "empty" }, "Nenhuma conversa ainda. Abra um anúncio e toque em Entrar em contato.")); return; }
  const rows = await Promise.all([...last].map(async ([id, m]) => {
    const p = await getProfile(id);
    return h("div", { class: "row", onclick: () => go("/dm/" + id) }, avatar(p, 44),
      h("div", { class: "g" }, h("b", {}, p?.name || "Pessoa"), h("small", {}, (m.sender_id === me ? "Você: " : "") + (m.body || "📷 Foto"))),
      h("small", { class: "mut" }, ago(m.created_at)));
  }));
  dms.replaceChildren(...rows);
}

export async function roomScreen(box, kind, peerId) {
  const me = S.user.id, isCity = kind === "city";
  if (!isCity && peerId === me) return go("/chats");
  const room = isCity ? "city:" + S.me.city_key : "dm:" + [me, peerId].sort().join(":");
  const peer = isCity ? null : await getProfile(peerId);
  const list = h("div", { class: "msgs" });
  const inp = h("input", { placeholder: "Mensagem...", maxlength: 1000 });
  const seen = new Set();
  let lastAt = null, lastDay = "", lastSender = null, pending = null, sending = false;
  let q = Promise.resolve();
  const enqueue = (m) => (q = q.then(() => add(m)).catch(() => {}));

  async function add(m) {
    if (seen.has(m.id)) return;
    seen.add(m.id); lastAt = m.created_at;
    list.querySelector("#hint")?.remove();
    const mineMsg = m.sender_id === me;
    const author = isCity && !mineMsg ? await getProfile(m.sender_id) : null;
    const stick = mineMsg || list.scrollHeight - list.scrollTop - list.clientHeight < 160;
    const day = new Date(m.created_at).toDateString();
    if (day !== lastDay) { list.append(h("div", { class: "day" }, dayLabel(m.created_at))); lastDay = day; lastSender = null; }
    const first = lastSender !== m.sender_id; lastSender = m.sender_id;
    const img = safeUrl(m.image_url);
    const bubble = h("div", { class: "b" + (mineMsg ? " me" : "") },
      isCity && !mineMsg && first ? h("small", {}, author?.name || "Pessoa") : null,
      img ? h("img", { class: "mimg", src: img, alt: "Foto", loading: "lazy", onclick: () => viewer(img), onload: () => { if (stick) list.scrollTop = list.scrollHeight; } }) : null,
      m.body ? h("div", {}, m.body) : null,
      h("span", { class: "t" }, hhmm(m.created_at)));
    const lead = isCity && !mineMsg ? (first ? avatar(author, 30, () => go("/user/" + m.sender_id)) : h("div", { class: "sp" })) : null;
    list.append(h("div", { class: "mrow" + (mineMsg ? " me" : "") + (first ? "" : " same") }, lead, bubble));
    if (stick) list.scrollTop = list.scrollHeight;
  }
  async function fetchNew() {
    if (!lastAt) {
      const { data } = await supabase.from("cx_messages").select("*").eq("room", room).order("created_at", { ascending: false }).limit(60);
      for (const m of (data || []).reverse()) enqueue(m);
      await q;
      if (!data?.length && !list.querySelector("#hint")) list.append(h("p", { class: "empty", id: "hint" }, isCity ? "Seja o primeiro a falar com a cidade!" : "Diga oi 👋"));
    } else {
      const { data } = await supabase.from("cx_messages").select("*").eq("room", room).gt("created_at", lastAt).order("created_at");
      for (const m of data || []) enqueue(m);
      await q;
    }
  }

  // foto escolhida (aparece uma prévia em cima da caixa de mensagem)
  const prev = h("div", { class: "cprev", style: "display:none" });
  const drawPending = () => {
    prev.style.display = pending ? "" : "none";
    prev.replaceChildren(...(pending ? [h("div", { class: "pv" }, h("img", { src: pending.url, alt: "" }),
      h("button", { "aria-label": "Remover foto", onclick: () => { pending = null; drawPending(); } }, icon("x", 14)))] : []));
  };
  const fileInp = h("input", { type: "file", accept: "image/*", style: "display:none" });
  fileInp.addEventListener("change", async () => {
    const f = fileInp.files[0]; fileInp.value = "";
    if (!f || !f.type.startsWith("image/")) return;
    const blob = await compressImage(f, 1280);
    pending = { blob, url: URL.createObjectURL(blob) }; drawPending();
  });
  const sendBtn = h("button", { class: "ib", "aria-label": "Enviar", onclick: send }, icon("send", 18));

  async function send() {
    const body = inp.value.trim();
    if ((!body && !pending) || sending) return;
    sending = true; sendBtn.disabled = true;
    const row = { room, sender_id: me, recipient_id: isCity ? null : peerId, body };
    try {
      if (pending) {
        const path = `${me}/chat-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`;
        const { error: e1 } = await supabase.storage.from(BUCKET).upload(path, pending.blob, { contentType: "image/jpeg" });
        if (e1) throw e1;
        row.image_url = supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
      }
      const { data, error } = await supabase.from("cx_messages").insert(row).select().single();
      if (error) throw error;
      inp.value = ""; pending = null; drawPending(); enqueue(data);
    } catch { toast("Não foi possível enviar"); }
    sending = false; sendBtn.disabled = false;
  }
  inp.addEventListener("keydown", (e) => e.key === "Enter" && send());

  box.append(h("div", { class: "chatpage" },
    topbar(isCity ? "Chat de " + S.me.city_name : peer?.name || "Conversa", { back: true,
      right: peer ? avatar(peer, 36, () => go("/user/" + peerId)) : null }),
    list,
    h("div", { class: "composewrap" }, prev,
      h("div", { class: "compose" },
        h("button", { class: "ib att", "aria-label": "Enviar foto", onclick: () => fileInp.click() }, icon("image", 22), fileInp),
        inp, sendBtn))));
  box.style.height = "100%";
  await fetchNew();
  const ch = supabase.channel("room-" + room)
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "cx_messages", filter: `room=eq.${room}` }, (p) => enqueue(p.new)).subscribe();
  const timer = setInterval(fetchNew, 6000);
  return () => { clearInterval(timer); supabase.removeChannel(ch); box.style.height = ""; };
}
