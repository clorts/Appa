import { supabase } from "./supabase.js";
import { S, getProfile } from "./state.js";
import { avatar, go, h, topbar } from "./ui.js";
import { icon } from "./icons.js";
import { ago } from "./utils.js";

export async function chatsScreen(box) {
  const me = S.user.id;
  const dms = h("div", {}, h("p", { class: "empty" }, "Carregando..."));
  box.append(h("div", { class: "screen" }, topbar("Conversas"),
    h("div", { class: "row cityrow", onclick: () => go("/city") },
      h("div", { class: "av", style: "width:44px;height:44px;background:rgba(255,255,255,.25)" }, icon("chat", 22)),
      h("div", { class: "g" }, h("b", {}, "Chat de " + S.me.city_name), h("small", {}, "Público · todo mundo da cidade"))),
    h("div", { class: "sec" }, "Conversas privadas"), dms));
  const { data } = await supabase.from("cx_messages").select("*").not("recipient_id", "is", null).order("created_at", { ascending: false }).limit(200);
  const last = new Map();
  for (const m of data || []) { const o = m.sender_id === me ? m.recipient_id : m.sender_id; if (!last.has(o)) last.set(o, m); }
  if (!last.size) { dms.replaceChildren(h("p", { class: "empty" }, "Nenhuma conversa ainda. Abra um anúncio e toque em Conversar.")); return; }
  const rows = await Promise.all([...last].map(async ([id, m]) => {
    const p = await getProfile(id);
    return h("div", { class: "row", onclick: () => go("/dm/" + id) }, avatar(p, 44),
      h("div", { class: "g" }, h("b", {}, p?.name || "Pessoa"), h("small", {}, (m.sender_id === me ? "Você: " : "") + m.body)),
      h("small", { class: "mut" }, ago(m.created_at)));
  }));
  dms.replaceChildren(...rows);
}

export async function roomScreen(box, kind, peerId) {
  const me = S.user.id, isCity = kind === "city";
  if (!isCity && peerId === me) return go("/chats");
  const room = isCity ? "city:" + S.me.city_key : "dm:" + [me, peerId].sort().join(":");
  const peer = isCity ? null : await getProfile(peerId);
  const list = h("div", { class: "msgs" });
  const inp = h("input", { placeholder: "Mensagem...", maxlength: 1000 });
  const seen = new Set(); let lastAt = null;

  async function add(m) {
    if (seen.has(m.id)) return;
    seen.add(m.id); lastAt = m.created_at;
    const mineMsg = m.sender_id === me;
    const who = isCity && !mineMsg ? (await getProfile(m.sender_id))?.name || "Pessoa" : null;
    const near = list.scrollHeight - list.scrollTop - list.clientHeight < 120;
    list.append(h("div", { class: "b" + (mineMsg ? " me" : "") }, who ? h("small", {}, who) : null, m.body));
    if (near || mineMsg) list.scrollTop = list.scrollHeight;
  }
  async function fetchNew() {
    if (!lastAt) {
      const { data } = await supabase.from("cx_messages").select("*").eq("room", room).order("created_at", { ascending: false }).limit(60);
      for (const m of (data || []).reverse()) await add(m);
      if (!data?.length && !list.querySelector("#hint")) list.append(h("p", { class: "empty", id: "hint" }, isCity ? "Seja o primeiro a falar com a cidade!" : "Diga oi 👋"));
    } else {
      const { data } = await supabase.from("cx_messages").select("*").eq("room", room).gt("created_at", lastAt).order("created_at");
      for (const m of data || []) await add(m);
    }
    if (seen.size) list.querySelector("#hint")?.remove();
  }
  async function send() {
    const body = inp.value.trim(); if (!body) return;
    inp.value = "";
    const { data, error } = await supabase.from("cx_messages").insert({ room, sender_id: me, recipient_id: isCity ? null : peerId, body }).select().single();
    if (error) { inp.value = body; return; }
    list.querySelector("#hint")?.remove(); add(data);
  }
  inp.addEventListener("keydown", (e) => e.key === "Enter" && send());

  box.append(h("div", { class: "chatpage" },
    topbar(isCity ? "Chat de " + S.me.city_name : peer?.name || "Conversa", { back: true,
      right: peer ? avatar(peer, 36, () => go("/user/" + peerId)) : null }),
    list, h("div", { class: "compose" }, inp, h("button", { class: "ib", "aria-label": "Enviar", onclick: send }, icon("send", 18)))));
  box.style.height = "100%";
  await fetchNew();
  const ch = supabase.channel("room-" + room)
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "cx_messages", filter: `room=eq.${room}` }, (p) => add(p.new)).subscribe();
  const timer = setInterval(fetchNew, 6000);
  return () => { clearInterval(timer); supabase.removeChannel(ch); box.style.height = ""; };
}
