import { initSupabase, supabase } from "./supabase.js";
import { S, loadMe } from "./state.js";
import { h, injectCss, go } from "./ui.js";
import { icon } from "./icons.js";
import { splash } from "./splash.js";
import { authScreen, citySetupScreen } from "./auth.js";
import { feedScreen } from "./feed.js";
import { newPostScreen, postScreen } from "./post.js";
import { chatsScreen, roomScreen } from "./chat.js";
import { profileScreen } from "./profile.js";

const routes = {
  feed: (b) => feedScreen(b),
  chats: (b) => chatsScreen(b),
  me: (b) => profileScreen(b, S.user.id),
  new: (b) => newPostScreen(b),
  post: (b, a) => postScreen(b, a),
  user: (b, a) => profileScreen(b, a),
  city: (b) => roomScreen(b, "city"),
  dm: (b, a) => roomScreen(b, "dm", a),
};
const TABS = [["feed", "Início", "home"], ["chats", "Chat", "chat"], ["new", "Postar", "plus"], ["me", "Perfil", "user"]];

let view, appEl, cleanup = null, token = 0, started = false, listening = false;

async function render() {
  if (!started) return;
  cleanup?.(); cleanup = null;
  const my = ++token;
  const [seg, arg] = (location.hash.replace(/^#\/?/, "") || "feed").split("/");
  const name = routes[seg] ? seg : "feed";
  appEl.classList.toggle("notabs", !["feed", "chats", "me"].includes(name));
  appEl.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.r === name));
  view.replaceChildren(); view.scrollTop = 0;
  try {
    const c = await routes[name](view, arg);
    if (my !== token) c?.(); else cleanup = c || null;
  } catch (e) {
    console.error(e);
    if (my === token) view.replaceChildren(h("div", { class: "empty" }, h("p", {}, "Algo deu errado."), h("p", {}, h("button", { class: "btn sm", onclick: render }, "Tentar de novo"))));
  }
}

function startApp() {
  document.body.replaceChildren();
  view = h("main", { id: "view" });
  appEl = h("div", { id: "app" }, view, h("nav", { class: "tabs" },
    TABS.map(([r, l, i]) => h("button", { class: "tab" + (r === "new" ? " post" : ""), "data-r": r, onclick: () => go("/" + r) }, h("i", {}, icon(i, 22)), h("small", {}, l)))));
  document.body.append(appEl);
  started = true;
  if (!listening) { window.addEventListener("hashchange", render); listening = true; }
  if (!location.hash) location.hash = "#/feed"; else render();
}

function showScreen(el) { started = false; cleanup?.(); cleanup = null; document.body.replaceChildren(h("div", { id: "app" }, h("main", { id: "view" }, el))); }

let authBound = false;
async function boot(notice = "") {
  injectCss();
  document.body.replaceChildren();
  const sp = splash();
  await initSupabase();
  let session = null;
  if (supabase) session = (await supabase.auth.getSession()).data?.session;
  await sp;
  if (!supabase) {
    showScreen(h("div", { class: "empty" }, h("p", {}, "Sem conexão com a internet."), h("p", {}, h("button", { class: "btn sm", onclick: () => boot() }, "Tentar de novo"))));
    return;
  }
  if (!authBound) { authBound = true; supabase.auth.onAuthStateChange((ev) => { if (ev === "SIGNED_OUT") { location.hash = ""; boot(); } }); }
  if (!session) return showScreen(authScreen(() => boot(), notice));
  S.user = session.user;
  S.me = await loadMe(session.user);
  if (!S.me) return showScreen(authScreen(() => boot(), "Não foi possível carregar seu perfil. Rode o SQL do Supabase (README)."));
  if (!S.me.city_key) return showScreen(citySetupScreen(startApp));
  startApp();
}

boot();
