import { SUPABASE_KEY, SUPABASE_URL } from "./config.js";

export let supabase = null;

export async function initSupabase() {
  try {
    const lib = await import("https://esm.sh/@supabase/supabase-js@2.45.4");
    supabase = lib.createClient(SUPABASE_URL, SUPABASE_KEY);
  } catch (err) {
    console.warn("Supabase indisponível:", err);
    supabase = null;
  }
  return supabase;
}
