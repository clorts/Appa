import { supabase } from "./supabase.js";
import { BUCKET, KINDS, MAX_PHOTOS, MAX_VIDEOS, MAX_VIDEO_MB, MIN_PHOTOS, MIN_VIDEOS, PERIODS } from "./config.js";
import { S } from "./state.js";
import { avatar, go, h, label, toast, topbar } from "./ui.js";
import { icon } from "./icons.js";
import { ago, baseUrl, compressImage, priceText, safeUrl, share } from "./utils.js";

export function newPostScreen(box) {
  let kind = "vender";
  const photos = [], videos = [];
  const title = h("input", { maxlength: 80, placeholder: "Ex.: Bicicleta aro 29" });
  const desc = h("textarea", { rows: 5, maxlength: 2000, placeholder: "Descreva tudo: estado, tamanho, defeitos, como entregar..." });
  const price = h("input", { type: "text", inputmode: "decimal", placeholder: "0,00" });
  const period = h("select", {}, Object.entries(PERIODS).map(([k, v]) => h("option", { value: k }, "Por " + v)));
  const priceBox = h("div", { class: "row2", style: "grid-template-columns:1fr 140px" }, price, period);
  const priceLb = label("Preço (R$)", priceBox);
  const seg = h("div", { class: "seg" });
  const pPrev = h("div", { class: "pvs" }), vPrev = h("div", { class: "pvs" });
  const pInfo = h("small", { class: "mut" }), vInfo = h("small", { class: "mut" });
  const err = h("p", { class: "err" });
  const btn = h("button", { class: "btn", onclick: publish }, "Publicar");

  const drawKind = () => {
    seg.replaceChildren(...Object.entries(KINDS).map(([k, v]) => h("button", {
      class: kind === k ? "on" : "", style: kind === k ? `background:${v.color}` : "", onclick: () => { kind = k; drawKind(); } }, v.label)));
    priceLb.style.display = kind === "doar" ? "none" : "";
    period.style.display = kind === "alugar" ? "" : "none";
    priceBox.style.gridTemplateColumns = kind === "alugar" ? "1fr 140px" : "1fr";
  };
  const drawMedia = () => {
    const mk = (arr, isImg, wrap) => wrap.replaceChildren(...arr.map((it, i) => h("div", { class: "pv" },
      isImg ? h("img", { src: it.url, alt: "" }) : h("video", { src: it.url, muted: true, playsinline: true }),
      h("button", { "aria-label": "Remover", onclick: () => { arr.splice(i, 1); drawMedia(); } }, icon("x", 14)))));
    mk(photos, true, pPrev); mk(videos, false, vPrev);
    pInfo.textContent = `${photos.length}/${MAX_PHOTOS} fotos (mínimo ${MIN_PHOTOS})`;
    vInfo.textContent = `${videos.length}/${MAX_VIDEOS} vídeos` + (MIN_VIDEOS ? ` (mínimo ${MIN_VIDEOS})` : " (opcional)");
  };
  const picker = (accept, arr, max, isImg) => {
    const inp = h("input", { type: "file", accept, multiple: true, style: "display:none" });
    inp.addEventListener("change", () => {
      for (const f of inp.files) {
        if (arr.length >= max) { toast(`Máximo de ${max} ${isImg ? "fotos" : "vídeos"}`); break; }
        if (!f.type.startsWith(isImg ? "image/" : "video/")) continue;
        if (!isImg && f.size > MAX_VIDEO_MB * 1048576) { toast(`Vídeo grande demais (máx. ${MAX_VIDEO_MB} MB)`); continue; }
        arr.push({ file: f, url: URL.createObjectURL(f) });
      }
      inp.value = ""; drawMedia();
    });
    return h("button", { class: "btn ghost", onclick: () => inp.click() }, icon(isImg ? "image" : "video", 18), isImg ? "Adicionar fotos" : "Adicionar vídeos", inp);
  };

  async function publish() {
    err.textContent = "";
    const pr = parseFloat(price.value.replace(",", "."));
    if (title.value.trim().length < 3) return (err.textContent = "Coloque um título");
    if (desc.value.trim().length < 10) return (err.textContent = "Coloque uma descrição (mín. 10 letras)");
    if (kind !== "doar" && !(pr > 0)) return (err.textContent = "Coloque o preço");
    if (photos.length < MIN_PHOTOS) return (err.textContent = `Adicione pelo menos ${MIN_PHOTOS} fotos`);
    if (videos.length < MIN_VIDEOS) return (err.textContent = `Adicione pelo menos ${MIN_VIDEOS} vídeo`);
    btn.disabled = true;
    let done = 0; const total = photos.length + videos.length;
    const up = async (it, isImg) => {
      const blob = isImg ? await compressImage(it.file) : it.file;
      const ext = isImg ? "jpg" : ((it.file.name.split(".").pop() || "mp4").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 5) || "mp4");
      const path = `${S.user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const { error } = await supabase.storage.from(BUCKET).upload(path, blob, { contentType: isImg ? "image/jpeg" : it.file.type || "video/mp4" });
      if (error) throw error;
      btn.textContent = `Enviando ${++done}/${total}...`;
      return supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
    };
    try {
      const pu = []; for (const p of photos) pu.push(await up(p, true));
      const vu = []; for (const v of videos) vu.push(await up(v, false));
      const { data, error } = await supabase.from("cx_posts").insert({
        user_id: S.user.id, city_key: S.me.city_key, kind, title: title.value.trim(), description: desc.value.trim(),
        price: kind === "doar" ? null : pr, rent_period: kind === "alugar" ? period.value : null, photos: pu, videos: vu,
      }).select("id").single();
      if (error) throw error;
      toast("Anúncio publicado!"); go("/post/" + data.id);
    } catch (e) { err.textContent = "Não foi possível publicar. Verifique a internet e tente de novo."; btn.disabled = false; btn.textContent = "Publicar"; }
  }

  box.append(h("div", { class: "screen" }, topbar("Novo anúncio", { back: true }),
    h("div", { class: "form" }, seg, label("Título", title), label("Descrição", desc), priceLb,
      h("div", {}, h("b", {}, "Fotos "), pInfo), picker("image/*", photos, MAX_PHOTOS, true), pPrev,
      h("div", {}, h("b", {}, "Vídeos "), vInfo), picker("video/*", videos, MAX_VIDEOS, false), vPrev,
      err, btn)));
  drawKind(); drawMedia();
}

export async function postScreen(box, id) {
  const screen = h("div", { class: "screen" }, topbar("Anúncio", { back: true }));
  box.append(screen);
  const { data: p } = await supabase.from("cx_posts").select("*, author:cx_profiles!user_id(id,name,username,avatar_url,city_name,uf)").eq("id", id).maybeSingle();
  if (!p) { screen.append(h("p", { class: "empty" }, "Anúncio não encontrado (talvez já foi apagado).")); return; }
  const mine = p.user_id === S.user.id, k = KINDS[p.kind];
  const media = [...p.photos.map((u) => ["i", u]), ...p.videos.map((u) => ["v", u])].filter(([, u]) => safeUrl(u));
  const cnt = h("span", { class: "cnt" }, `1/${media.length}`);
  const car = h("div", { class: "carousel" }, media.map(([t, u]) => (t === "i" ? h("img", { src: u, alt: "" }) : h("video", { src: u, controls: true, playsinline: true, preload: "metadata" }))));
  car.addEventListener("scroll", () => { cnt.textContent = `${Math.round(car.scrollLeft / car.clientWidth) + 1}/${media.length}`; });

  async function delPost() {
    if (!confirm("Apagar este anúncio?")) return;
    const paths = [...p.photos, ...p.videos].map((u) => u.split(`/object/public/${BUCKET}/`)[1]).filter(Boolean);
    const { error } = await supabase.from("cx_posts").delete().eq("id", id);
    if (error) return toast("Não foi possível apagar");
    if (paths.length) await supabase.storage.from(BUCKET).remove(paths);
    toast("Anúncio apagado"); go("/feed");
  }

  const cList = h("div", { class: "comments" });
  async function loadComments() {
    const { data } = await supabase.from("cx_comments").select("*, author:cx_profiles!user_id(id,name,username,avatar_url)").eq("post_id", id).order("created_at");
    cList.replaceChildren(...(data?.length ? data.map((c) => h("div", { class: "crow" },
      avatar(c.author, 34, () => go("/user/" + c.user_id)),
      h("div", { class: "cb" }, h("b", {}, c.author?.name || "Pessoa"), " ", h("small", { class: "mut" }, ago(c.created_at)), h("div", {}, c.body)),
      c.user_id === S.user.id || mine ? h("button", { class: "ib2", "aria-label": "Apagar comentário", onclick: async () => {
        if (!confirm("Apagar este comentário?")) return;
        await supabase.from("cx_comments").delete().eq("id", c.id); loadComments(); } }, icon("trash", 17)) : null))
      : [h("p", { class: "mut" }, "Nenhum comentário ainda.")]));
  }
  const cin = h("input", { placeholder: "Escreva um comentário...", maxlength: 500 });
  const send = async () => {
    const body = cin.value.trim(); if (!body) return;
    cin.value = "";
    const { error } = await supabase.from("cx_comments").insert({ post_id: id, user_id: S.user.id, body });
    if (error) { toast("Não foi possível comentar"); cin.value = body; } else loadComments();
  };
  cin.addEventListener("keydown", (e) => e.key === "Enter" && send());

  screen.append(
    h("div", { class: "cwrap" }, car, media.length > 1 ? cnt : null),
    h("div", { class: "det" },
      h("span", { class: "badge", style: `position:static;align-self:flex-start;background:${k.color}` }, k.label),
      h("div", { class: "price" }, priceText(p)),
      h("h2", {}, p.title),
      h("small", { class: "mut" }, "Publicado " + ago(p.created_at) + " · " + (p.author?.city_name || "")),
      h("p", { class: "desc" }, p.description),
      h("div", { class: "who", onclick: () => go(mine ? "/me" : "/user/" + p.user_id) }, avatar(p.author, 42),
        h("div", {}, h("b", {}, p.author?.name || "Pessoa"), h("small", { class: "mut" }, "@" + (p.author?.username || ""))) ),
      h("div", { class: "acts" },
        !mine ? h("button", { class: "btn", onclick: () => go("/dm/" + p.user_id) }, icon("chat", 18), "Conversar") : null,
        h("button", { class: "btn ghost", onclick: () => share(p.title, `${k.label}: ${p.title} — ${priceText(p)} no City Exchange`, baseUrl() + "/#/post/" + id) }, icon("share", 18), "Compartilhar"),
        mine ? h("button", { class: "btn red", onclick: delPost }, icon("trash", 18), "Apagar") : null)),
    h("h3", { class: "sec" }, "Comentários"), cList,
    h("div", { class: "compose" }, cin, h("button", { class: "ib", "aria-label": "Enviar", onclick: send }, icon("send", 18))));
  loadComments();
}
