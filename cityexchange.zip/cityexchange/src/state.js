import { supabase } from "./supabase.js";

export const S = { user: null, me: null };
const cache = new Map();

export const cacheProfile = (p) => p && cache.set(p.id, p);

export async function getProfile(id) {
  if (cache.has(id)) return cache.get(id);
  const { data } = await supabase.from("cx_profiles").select("*").eq("id", id).maybeSingle();
  if (data) cache.set(id, data);
  return data;
}

// Nome vem da conta (Google) ou do começo do e-mail; a pessoa pode mudar depois no perfil
export function nameFromUser(user) {
  const m = user.user_metadata || {};
  const given = String(m.full_name || m.name || "").trim();
  if (given && given !== "Pessoa") return given.slice(0, 40);
  const raw = String(user.email || "").split("@")[0].replace(/[._-]+/g, " ").trim();
  const nice = raw.split(/\s+/).filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join(" ");
  return (nice || "Pessoa").slice(0, 40);
}

export async function loadMe(user) {
  let { data } = await supabase.from("cx_profiles").select("*").eq("id", user.id).maybeSingle();
  if (!data) {
    const m = user.user_metadata || {};
    const base = (m.username || user.email.split("@")[0]).toLowerCase().replace(/[^a-z0-9_.]/g, "").slice(0, 20);
    const r = await supabase.from("cx_profiles").insert({
      id: user.id, name: nameFromUser(user), username: base.length >= 3 ? base : "user" + Math.floor(Math.random() * 99999),
      uf: m.uf, city_name: m.city_name, city_key: m.city_key || "",
    }).select().single();
    data = r.data;
  }
  if (data && (!data.name || data.name === "Pessoa")) {
    const nm = nameFromUser(user);
    if (nm !== "Pessoa") {
      const r2 = await supabase.from("cx_profiles").update({ name: nm }).eq("id", user.id).select().single();
      if (r2.data) data = r2.data;
    }
  }
  cacheProfile(data);
  return data;
}
