import { supabase } from "./supabase.js";

export const S = { user: null, me: null };
const cache = new Map();

export const cacheProfile = (p) => p && cache.set(p.id, p);

export async function getProfile(id) {
  if (cache.has(id)) return cache.get(id);
  const { data } = await supabase.from("cx_profiles").select("*").eq("id", id).maybeSingle();
  if (data) cache.set(id, data);
  return data;
}

export async function loadMe(user) {
  let { data } = await supabase.from("cx_profiles").select("*").eq("id", user.id).maybeSingle();
  if (!data) {
    const m = user.user_metadata || {};
    const base = (m.username || user.email.split("@")[0]).toLowerCase().replace(/[^a-z0-9_.]/g, "").slice(0, 20);
    const r = await supabase.from("cx_profiles").insert({
      id: user.id, name: m.name || "Pessoa", username: base.length >= 3 ? base : "user" + Math.floor(Math.random() * 99999),
      uf: m.uf, city_name: m.city_name, city_key: m.city_key || "",
    }).select().single();
    data = r.data;
  }
  cacheProfile(data);
  return data;
}
