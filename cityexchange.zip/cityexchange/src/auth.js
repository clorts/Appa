import { supabase } from "./supabase.js";
import { UFS } from "./config.js";
import { h, label } from "./ui.js";
import { slug } from "./utils.js";
import { S, cacheProfile } from "./state.js";

// Escolha de estado + cidade (lista oficial do IBGE). Se a lista não carregar, digita a cidade.
export function cityPicker(init = {}) {
  const uf = h("select", {}, h("option", { value: "" }, "UF"), UFS.map((u) => h("option", { value: u }, u)));
  let cityEl = h("select", { disabled: true }, h("option", {}, "Escolha o estado"));
  const wrap = h("div", {}, cityEl);
  async function loadCities(u, pre) {
    cityEl = h("select", {}, h("option", { value: "" }, "Carregando..."));
    wrap.replaceChildren(cityEl);
    try {
      const r = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${u}/municipios?orderBy=nome`);
      const j = await r.json();
      cityEl = h("select", {}, h("option", { value: "" }, "Cidade"), j.map((c) => h("option", { value: c.nome }, c.nome)));
    } catch {
      cityEl = h("input", { placeholder: "Nome da cidade" });
    }
    if (pre) cityEl.value = pre;
    wrap.replaceChildren(cityEl);
  }
  uf.addEventListener("change", () => uf.value && loadCities(uf.value));
  if (init.uf) { uf.value = init.uf; loadCities(init.uf, init.city); }
  return {
    el: h("div", { class: "row2" }, uf, wrap),
    get: () => {
      const c = (cityEl.value || "").trim();
      return uf.value && c ? { uf: uf.value, city: c, key: `${uf.value}-${slug(c)}` } : null;
    },
  };
}

const MSG = { "Invalid login credentials": "E-mail ou senha incorretos", "User already registered": "Este e-mail já tem conta", "Email not confirmed": "Confirme seu e-mail para entrar" };
const tr = (m) => MSG[m] || (m?.includes("at least") ? "A senha precisa de pelo menos 6 caracteres" : "Algo deu errado: " + m);

export function authScreen(onDone, notice = "") {
  let mode = "login";
  const box = h("div", { class: "auth" });
  function draw() {
    const name = h("input", { placeholder: "Seu nome", maxlength: 40 });
    const user = h("input", { placeholder: "usuario (sem espaço)", maxlength: 20, autocapitalize: "none" });
    const email = h("input", { type: "email", placeholder: "E-mail", autocomplete: "email" });
    const pass = h("input", { type: "password", placeholder: "Senha (mín. 6)", autocomplete: mode === "login" ? "current-password" : "new-password" });
    const cp = cityPicker();
    const err = h("p", { class: "err" }, notice);
    const btn = h("button", { class: "btn", onclick: submit }, mode === "login" ? "Entrar" : "Criar conta");
    async function submit() {
      err.textContent = "";
      if (!email.value || !pass.value) { err.textContent = "Preencha e-mail e senha"; return; }
      let meta;
      if (mode === "signup") {
        const c = cp.get();
        if (name.value.trim().length < 2) { err.textContent = "Coloque seu nome"; return; }
        if (!c) { err.textContent = "Escolha seu estado e sua cidade"; return; }
        meta = { name: name.value.trim(), username: user.value.trim().toLowerCase(), uf: c.uf, city_name: c.city, city_key: c.key };
      }
      btn.disabled = true;
      try {
        if (mode === "login") {
          const { error } = await supabase.auth.signInWithPassword({ email: email.value.trim(), password: pass.value });
          if (error) throw error;
        } else {
          const { data, error } = await supabase.auth.signUp({ email: email.value.trim(), password: pass.value, options: { data: meta } });
          if (error) throw error;
          if (!data.session) { notice = "Conta criada! Confirme seu e-mail e depois entre."; mode = "login"; draw(); return; }
        }
        onDone();
      } catch (e) { err.textContent = tr(e.message); }
      btn.disabled = false;
    }
    box.replaceChildren(
      h("img", { class: "logo", src: "/src/assets/icon.png", alt: "" }),
      h("h1", {}, "City Exchange"),
      h("p", { class: "tg" }, "Vender · Alugar · Doar na sua cidade"),
      h("div", { class: "seg" },
        ["login", "signup"].map((m) => h("button", { class: mode === m ? "on" : "", style: mode === m ? "background:var(--pri)" : "", onclick: () => { mode = m; notice = ""; draw(); } }, m === "login" ? "Entrar" : "Criar conta"))),
      mode === "signup" ? [label("Nome", name), label("Usuário", user), label("Sua cidade", cp.el)] : null,
      label("E-mail", email), label("Senha", pass), err, btn);
  }
  draw();
  return h("div", { class: "screen" }, box);
}

// Para contas que ainda não escolheram cidade
export function citySetupScreen(onDone) {
  const cp = cityPicker();
  const err = h("p", { class: "err" });
  const btn = h("button", { class: "btn", onclick: async () => {
    const c = cp.get();
    if (!c) { err.textContent = "Escolha estado e cidade"; return; }
    btn.disabled = true;
    const { data, error } = await supabase.from("cx_profiles").update({ uf: c.uf, city_name: c.city, city_key: c.key }).eq("id", S.user.id).select().single();
    if (error) { err.textContent = "Erro ao salvar"; btn.disabled = false; return; }
    S.me = data; cacheProfile(data); onDone();
  } }, "Entrar na comunidade");
  return h("div", { class: "screen" }, h("div", { class: "auth" },
    h("img", { class: "logo", src: "/src/assets/icon.png", alt: "" }),
    h("h1", {}, "Qual é a sua cidade?"), h("p", { class: "tg" }, "Você vai ver só os anúncios e o chat da sua cidade."),
    cp.el, err, btn));
}
