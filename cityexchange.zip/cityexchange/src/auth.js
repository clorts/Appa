import { supabase } from "./supabase.js";
import { UFS } from "./config.js";
import { h, label } from "./ui.js";
import { icon } from "./icons.js";
import { slug } from "./utils.js";
import { S, cacheProfile, nameFromUser } from "./state.js";

// Escolha de estado + cidade (lista oficial do IBGE). Se a lista não carregar, digita a cidade.
export function cityPicker(init = {}) {
  const uf = h("select", {}, h("option", { value: "" }, "UF"), UFS.map((u) => h("option", { value: u }, u)));
  let cityEl = h("select", { disabled: true }, h("option", {}, "Escolha o estado"));
  const wrap = h("div", {}, cityEl);
  async function loadCities(u, pre) {
    cityEl = h("select", {}, h("option", { value: "" }, "Carregando..."));
    wrap.replaceChildren(cityEl);
    try {
      const r = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${u}/municipios?orderBy=nome`);
      const j = await r.json();
      cityEl = h("select", {}, h("option", { value: "" }, "Cidade"), j.map((c) => h("option", { value: c.nome }, c.nome)));
    } catch {
      cityEl = h("input", { placeholder: "Nome da cidade" });
    }
    if (pre) cityEl.value = pre;
    wrap.replaceChildren(cityEl);
  }
  uf.addEventListener("change", () => uf.value && loadCities(uf.value));
  if (init.uf) { uf.value = init.uf; loadCities(init.uf, init.city); }
  return {
    el: h("div", { class: "row2" }, uf, wrap),
    get: () => {
      const c = (cityEl.value || "").trim();
      return uf.value && c ? { uf: uf.value, city: c, key: `${uf.value}-${slug(c)}` } : null;
    },
  };
}

const MSG = { "Invalid login credentials": "E-mail ou senha incorretos", "User already registered": "Este e-mail já tem conta. Toque em Entrar", "Email not confirmed": "Confirme seu e-mail para entrar" };
function tr(m = "") {
  if (MSG[m]) return MSG[m];
  if (/rate limit/i.test(m)) return "Muitas tentativas agora. Espere uns minutos e tente de novo.";
  if (/only request this after|security purposes/i.test(m)) return "Espere alguns segundos e tente de novo.";
  if (/at least|weak/i.test(m)) return "A senha precisa de pelo menos 6 caracteres";
  if (/valid email|invalid format/i.test(m)) return "Esse e-mail não parece certo";
  if (/network|fetch/i.test(m)) return "Sem internet. Tente de novo.";
  return "Algo deu errado: " + m;
}

// campo de senha com olhinho para ver o que digitou
function passField(autocomplete) {
  const pass = h("input", { type: "password", placeholder: "Senha (mín. 6)", autocomplete });
  const eye = h("button", { type: "button", class: "ib2 eye", "aria-label": "Mostrar senha" }, icon("eye", 20));
  eye.addEventListener("click", () => {
    const show = pass.type === "password";
    pass.type = show ? "text" : "password";
    eye.replaceChildren(icon(show ? "eyeoff" : "eye", 20));
  });
  return { pass, el: h("div", { class: "pw" }, pass, eye) };
}

export function authScreen(onDone, notice = "") {
  let mode = "login";
  const box = h("div", { class: "auth" });
  function draw() {
    const email = h("input", { type: "email", placeholder: "E-mail", autocomplete: "email" });
    const pf = passField(mode === "login" ? "current-password" : "new-password");
    const pass = pf.pass;
    const cp = cityPicker();
    const err = h("p", { class: "err" }, notice);
    const btn = h("button", { class: "btn", onclick: submit }, mode === "login" ? "Entrar" : "Criar conta");
    async function submit() {
      err.textContent = "";
      if (!email.value || !pass.value) { err.textContent = "Preencha e-mail e senha"; return; }
      let meta;
      if (mode === "signup") {
        const c = cp.get();
        if (!c) { err.textContent = "Escolha seu estado e sua cidade"; return; }
        // o nome vem do e-mail (a pessoa troca depois no perfil)
        meta = { name: nameFromUser({ email: email.value.trim() }), uf: c.uf, city_name: c.city, city_key: c.key };
      }
      btn.disabled = true;
      try {
        if (mode === "login") {
          const { error } = await supabase.auth.signInWithPassword({ email: email.value.trim(), password: pass.value });
          if (error) throw error;
        } else {
          const { data, error } = await supabase.auth.signUp({ email: email.value.trim(), password: pass.value, options: { data: meta } });
          if (error) throw error;
          if (data.user && data.user.identities && data.user.identities.length === 0) { notice = "Este e-mail já tem conta. Entre com a sua senha."; mode = "login"; draw(); return; }
          if (!data.session) { notice = "Conta criada! Confirme seu e-mail e depois entre."; mode = "login"; draw(); return; }
        }
        onDone();
      } catch (e) { err.textContent = tr(e.message); }
      btn.disabled = false;
    }
    // replaceChildren nativo não aceita lista nem null (era isso que mostrava "null" e "[object HTMLLabelElement]")
    box.replaceChildren(...[
      h("img", { class: "logo", src: "/src/assets/icon.png", alt: "" }),
      h("h1", {}, "City Exchange"),
      h("p", { class: "tg" }, "Vender · Alugar · Doar na sua cidade"),
      h("div", { class: "seg" },
        ["login", "signup"].map((m) => h("button", { class: mode === m ? "on" : "", style: mode === m ? "background:var(--pri)" : "", onclick: () => { mode = m; notice = ""; draw(); } }, m === "login" ? "Entrar" : "Criar conta"))),
      label("E-mail", email),
      label("Senha", pf.el),
      mode === "signup" ? label("Sua cidade", cp.el) : null,
      err, btn,
    ].filter(Boolean));
  }
  draw();
  return h("div", { class: "screen" }, box);
}

// Para contas que ainda não escolheram cidade
export function citySetupScreen(onDone) {
  const cp = cityPicker();
  const err = h("p", { class: "err" });
  const btn = h("button", { class: "btn", onclick: async () => {
    const c = cp.get();
    if (!c) { err.textContent = "Escolha estado e cidade"; return; }
    btn.disabled = true;
    const { data, error } = await supabase.from("cx_profiles").update({ uf: c.uf, city_name: c.city, city_key: c.key }).eq("id", S.user.id).select().single();
    if (error) { err.textContent = "Erro ao salvar"; btn.disabled = false; return; }
    S.me = data; cacheProfile(data); onDone();
  } }, "Entrar na comunidade");
  return h("div", { class: "screen" }, h("div", { class: "auth" },
    h("img", { class: "logo", src: "/src/assets/icon.png", alt: "" }),
    h("h1", {}, "Qual é a sua cidade?"), h("p", { class: "tg" }, "Você vai ver só os anúncios e o chat da sua cidade."),
    cp.el, err, btn));
}
