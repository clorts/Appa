import { supabase } from "./supabase.js";
import { S } from "./state.js";
import { h, toast } from "./ui.js";
import { icon } from "./icons.js";

// Botão de curtir (coração + quantidade) de um anúncio
export function likeButton(postId, start = null) {
  let n = start?.n || 0, liked = !!start?.liked, busy = false;
  const b = h("button", { class: "btn sm ghost like", "aria-label": "Curtir" });
  const draw = () => { b.replaceChildren(icon("heart", 18, liked), String(n)); b.classList.toggle("liked", liked); };
  async function load() {
    const { data, error } = await supabase.from("cx_likes").select("user_id").eq("post_id", postId);
    if (error) return;
    n = data.length; liked = data.some((x) => x.user_id === S.user.id); draw();
  }
  b.addEventListener("click", async (e) => {
    e.stopPropagation();
    if (busy) return; busy = true;
    const was = liked; liked = !liked; n += liked ? 1 : -1; draw();
    const r = was
      ? await supabase.from("cx_likes").delete().match({ post_id: postId, user_id: S.user.id })
      : await supabase.from("cx_likes").insert({ post_id: postId, user_id: S.user.id });
    busy = false;
    if (r.error) { liked = was; n += was ? 1 : -1; draw(); toast("Não foi possível agora"); }
  });
  draw(); load();
  return b;
}
