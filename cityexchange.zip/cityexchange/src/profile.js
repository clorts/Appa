import { supabase } from "./supabase.js";
import { BUCKET } from "./config.js";
import { S, cacheProfile, getProfile } from "./state.js";
import { avatar, go, h, label, refresh, sheet, toast, topbar } from "./ui.js";
import { icon } from "./icons.js";
import { ago, baseUrl, compressImage, share } from "./utils.js";
import { cityPicker } from "./auth.js";
import { postCard } from "./feed.js";

function editSheet() {
  const name = h("input", { maxlength: 40, value: S.me.name });
  const bio = h("textarea", { maxlength: 160, rows: 3, placeholder: "Fale um pouco sobre você" }, S.me.bio || "");
  const file = h("input", { type: "file", accept: "image/*" });
  const cp = cityPicker({ uf: S.me.uf, city: S.me.city_name });
  const err = h("p", { class: "err" });
  const btn = h("button", { class: "btn", onclick: save }, "Salvar");
  const sh = sheet(h("div", { class: "form" }, h("h2", {}, "Editar perfil"), label("Foto", file), label("Nome", name), label("Sobre você", bio), label("Cidade", cp.el), err, btn));
  async function save() {
    const c = cp.get();
    if (!c) return (err.textContent = "Escolha estado e cidade");
    if (name.value.trim().length < 2) return (err.textContent = "Coloque seu nome");
    btn.disabled = true;
    try {
      const upd = { name: name.value.trim(), bio: bio.value.trim(), uf: c.uf, city_name: c.city, city_key: c.key };
      if (file.files[0]) {
        const path = `${S.user.id}/avatar-${Date.now()}.jpg`;
        const { error: e1 } = await supabase.storage.from(BUCKET).upload(path, await compressImage(file.files[0], 400), { contentType: "image/jpeg" });
        if (e1) throw e1;
        upd.avatar_url = supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
      }
      const { data, error } = await supabase.from("cx_profiles").update(upd).eq("id", S.user.id).select().single();
      if (error) throw error;
      S.me = data; cacheProfile(data); sh.close(); refresh();
    } catch { err.textContent = "Não foi possível salvar."; btn.disabled = false; }
  }
}

export async function profileScreen(box, id) {
  const me = S.user.id, mine = id === me;
  const p = mine ? S.me : await getProfile(id);
  const screen = h("div", { class: "screen" }, topbar(mine ? "Meu perfil" : "Perfil", { back: !mine,
    right: mine ? h("button", { class: "ib", "aria-label": "Editar", onclick: editSheet }, icon("edit", 18)) : null }));
  box.append(screen);
  if (!p) { screen.append(h("p", { class: "empty" }, "Perfil não encontrado.")); return; }

  const cnt = (t, col, v) => supabase.from(t).select("*", { count: "exact", head: true }).eq(col, v);
  const [sc, pc, iSup, theySup] = await Promise.all([
    cnt("cx_supports", "supported_id", id), cnt("cx_posts", "user_id", id),
    mine ? null : supabase.from("cx_supports").select("created_at").match({ supporter_id: me, supported_id: id }).maybeSingle(),
    mine ? null : supabase.from("cx_supports").select("created_at").match({ supporter_id: id, supported_id: me }).maybeSingle(),
  ]);
  let supporters = sc.count || 0, supporting = !!iSup?.data;
  const supNum = h("b", {}, supporters);
  const supBtn = h("button", { class: "btn sm" + (supporting ? " ghost" : ""), onclick: toggle });
  const drawBtn = () => { supBtn.replaceChildren(icon("heart", 17), supporting ? "Apoiando" : "Apoiar"); supBtn.className = "btn sm" + (supporting ? " ghost" : ""); supNum.textContent = supporters; };
  async function toggle() {
    supBtn.disabled = true;
    const r = supporting
      ? await supabase.from("cx_supports").delete().match({ supporter_id: me, supported_id: id })
      : await supabase.from("cx_supports").insert({ supporter_id: me, supported_id: id });
    supBtn.disabled = false;
    if (r.error) return toast("Não foi possível agora");
    supporting = !supporting; supporters += supporting ? 1 : -1; drawBtn();
    if (tab === "sup") drawTab();
  }

  const body = h("div", {});
  let tab = "posts";
  const tabs = h("div", { class: "tabs2" });
  async function drawTab() {
    tabs.replaceChildren(...[["posts", "Anúncios"], ["sup", "Apoiadores"]].map(([k, l]) => h("button", { class: tab === k ? "on" : "", onclick: () => { tab = k; drawTab(); } }, l)));
    body.replaceChildren(h("p", { class: "empty" }, "Carregando..."));
    if (tab === "posts") {
      const { data } = await supabase.from("cx_posts").select("*").eq("user_id", id).order("created_at", { ascending: false }).limit(60);
      body.replaceChildren(h("div", { class: "grid" }, ...(data?.length ? data.map((x) => postCard({ ...x, author: p })) : [h("p", { class: "empty" }, "Nenhum anúncio ainda.")])));
    } else {
      const { data } = await supabase.from("cx_supports").select("*, who:cx_profiles!supporter_id(id,name,username,avatar_url)").eq("supported_id", id).order("created_at", { ascending: false }).limit(100);
      body.replaceChildren(h("div", { style: "padding-top:14px" }, ...(data?.length ? data.map((s) => h("div", { class: "row", onclick: () => go(s.supporter_id === me ? "/me" : "/user/" + s.supporter_id) },
        avatar(s.who, 44), h("div", { class: "g" }, h("b", {}, s.who?.name || "Pessoa"), h("small", {}, mine ? "te apoiou" : "apoia " + p.name.split(" ")[0])), h("small", { class: "mut" }, ago(s.created_at))))
        : [h("p", { class: "empty" }, mine ? "Quando alguém te apoiar, aparece aqui." : "Seja o primeiro a apoiar!")])));
    }
  }

  screen.append(h("div", { class: "phead" }),
    h("div", { class: "pinfo" }, avatar(p, 92),
      h("h2", {}, p.name), h("small", { class: "mut" }, "@" + p.username + " · " + (p.city_name || "") + (p.uf ? " - " + p.uf : "")),
      !mine && theySup?.data ? h("span", { class: "supbadge" }, "te apoiou") : null,
      p.bio ? h("p", {}, p.bio) : null,
      h("div", { class: "stats" }, h("div", {}, supNum, h("small", { class: "mut" }, "apoiadores")), h("div", {}, h("b", {}, pc.count || 0), h("small", { class: "mut" }, "anúncios"))),
      h("div", { class: "acts", style: "margin-top:6px" },
        mine ? [h("button", { class: "btn sm ghost", onclick: () => share("City Exchange", "Vem pra comunidade da nossa cidade: vender, alugar e doar!", baseUrl()) }, icon("share", 17), "Convidar amigos"),
                h("button", { class: "btn sm red", onclick: async () => { await supabase.auth.signOut(); } }, "Sair")]
             : [supBtn, h("button", { class: "btn sm ghost", onclick: () => go("/dm/" + id) }, icon("chat", 17), "Mensagem")])),
    tabs, body);
  drawBtn(); drawTab();
}
