import { supabase } from "./supabase.js";
import { KINDS } from "./config.js";
import { S } from "./state.js";
import { h, go } from "./ui.js";
import { icon } from "./icons.js";
import { ago, debounce, priceText, safeUrl } from "./utils.js";

export function postCard(p) {
  const k = KINDS[p.kind];
  const img = safeUrl(p.photos?.[0]);
  return h("article", { class: "card", onclick: () => go("/post/" + p.id) },
    h("div", { class: "thumb" },
      img ? h("img", { src: img, loading: "lazy", alt: "" }) : null,
      h("span", { class: "badge", style: `background:${k.color}` }, k.label),
      p.videos?.length ? h("span", { class: "vid" }, icon("video", 13), p.videos.length) : null),
    h("div", { class: "cbody" },
      h("div", { class: "price" }, priceText(p)),
      h("h3", {}, p.title),
      h("div", { class: "meta" }, (p.author?.name || "") + " · " + ago(p.created_at))));
}

export function feedScreen(box) {
  let kind = "", q = "", tick = 0;
  const list = h("div", { class: "grid" });
  const chips = h("div", { class: "chips" });
  const search = h("input", { type: "search", placeholder: "Pesquisar em " + S.me.city_name + "..." });
  search.addEventListener("input", debounce(() => { q = search.value; load(); }, 350));

  const drawChips = () => chips.replaceChildren(...[["", "Tudo"], ...Object.entries(KINDS).map(([k, v]) => [k, v.label])]
    .map(([k, l]) => h("button", { class: "chip" + (kind === k ? " on" : ""), onclick: () => { kind = k; drawChips(); load(); } }, l)));

  async function load() {
    const t = ++tick;
    list.replaceChildren(h("p", { class: "empty" }, "Carregando..."));
    let qq = supabase.from("cx_posts").select("*, author:cx_profiles!user_id(id,name,username,avatar_url)")
      .eq("city_key", S.me.city_key).order("created_at", { ascending: false }).limit(60);
    if (kind) qq = qq.eq("kind", kind);
    const term = q.replace(/[,()%*]/g, " ").trim();
    if (term) qq = qq.or(`title.ilike.%${term}%,description.ilike.%${term}%`);
    const { data, error } = await qq;
    if (t !== tick) return;
    if (error) { list.replaceChildren(h("p", { class: "empty" }, "Não deu para carregar. Tente de novo.")); return; }
    list.replaceChildren(...(data.length ? data.map(postCard)
      : [h("p", { class: "empty" }, term || kind ? "Nada encontrado por aqui." : "Ainda não tem anúncios na sua cidade. Seja o primeiro a postar! ✨")]));
  }

  box.append(h("div", { class: "screen" },
    h("header", { class: "top" },
      h("img", { class: "mini", src: "/src/assets/icon.png", alt: "" }),
      h("div", { style: "flex:1;min-width:0" }, h("h1", {}, "City Exchange"), h("small", {}, icon("pin", 13), S.me.city_name + " · " + S.me.uf))),
    h("div", { class: "pad" }, h("div", { class: "sbox" }, icon("search", 18), search)),
    chips, list));
  drawChips();
  load();
}
