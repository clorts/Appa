import { supabase } from "./supabase.js";
import { KINDS } from "./config.js";
import { S } from "./state.js";
import { avatar, h, go, sheet } from "./ui.js";
import { icon } from "./icons.js";
import { ago, debounce, posterOf, priceText, safeUrl } from "./utils.js";
import { likeButton } from "./likes.js";

export const POST_SEL = "*, author:cx_profiles!user_id(id,name,username,avatar_url)";
const POST_SEL_COUNTS = POST_SEL + ", likes:cx_likes(count), comments:cx_comments(count)";

// Tenta trazer também curtidas/comentários; se a tabela de curtidas ainda não existe, traz só o básico
export async function queryPosts(build) {
  let r = await build(POST_SEL_COUNTS);
  if (r.error) r = await build(POST_SEL);
  return r;
}

const num = (x) => x?.[0]?.count ?? null;

export function postCard(p) {
  const k = KINDS[p.kind];
  const img = safeUrl(p.photos?.[0]);
  const lk = num(p.likes), cm = num(p.comments);
  return h("article", { class: "card", onclick: () => openPostPanel(p) },
    h("div", { class: "thumb" },
      img ? h("img", { src: img, loading: "lazy", alt: "" }) : null,
      h("span", { class: "badge", style: `background:${k.color}` }, k.label),
      p.videos?.length ? h("span", { class: "vid" }, icon("video", 13), p.videos.length) : null),
    h("div", { class: "cbody" },
      h("div", { class: "price" }, priceText(p)),
      h("h3", {}, p.title),
      h("div", { class: "meta" }, (p.author?.name || "") + " · " + ago(p.created_at)),
      lk !== null ? h("div", { class: "stat" }, h("span", {}, icon("heart", 13), lk), h("span", {}, icon("chat", 13), cm ?? 0)) : null));
}

// Painel que sobe de baixo quando toca no anúncio
export function openPostPanel(p) {
  const k = KINDS[p.kind], mine = p.user_id === S.user.id;
  const vid = safeUrl(p.videos?.[0]), img = safeUrl(p.photos?.[0]);
  const media = vid
    ? h("div", { class: "pmedia" }, h("video", { src: vid, poster: posterOf(vid), controls: true, playsinline: true, preload: "metadata" }))
    : img ? h("div", { class: "pmedia" }, h("img", { src: img, alt: "" })) : null;
  const total = (p.photos?.length || 0) + (p.videos?.length || 0);
  let sh;
  const to = (path) => { sh.close(); go(path); };
  sh = sheet(h("div", { class: "panel" },
    h("div", { class: "grab" }), media,
    h("div", { class: "pbody" },
      h("span", { class: "badge", style: `position:static;align-self:flex-start;background:${k.color}` }, k.label),
      h("div", { class: "price" }, priceText(p)),
      h("h2", {}, p.title),
      h("p", { class: "desc clamp" }, p.description),
      h("div", { class: "cnts" },
        p.photos?.length ? h("span", {}, icon("image", 15), p.photos.length + " fotos") : null,
        p.videos?.length ? h("span", {}, icon("video", 15), p.videos.length + " vídeos") : null,
        h("span", {}, total + " no total")),
      h("div", { class: "who", onclick: () => to(mine ? "/me" : "/user/" + p.user_id) }, avatar(p.author, 40),
        h("div", {}, h("b", {}, p.author?.name || "Pessoa"), h("small", { class: "mut" }, "@" + (p.author?.username || "")))),
      h("button", { class: "btn", onclick: () => to("/post/" + p.id) }, "Ver completo"),
      h("div", { class: "acts" },
        likeButton(p.id, { n: num(p.likes) || 0 }),
        !mine ? h("button", { class: "btn ghost", onclick: () => to("/dm/" + p.user_id) }, icon("chat", 18), "Entrar em contato") : null))));
}

export function feedScreen(box) {
  let kind = "", q = "", tick = 0;
  const list = h("div", { class: "grid" });
  const chips = h("div", { class: "chips" });
  const search = h("input", { type: "search", placeholder: "Pesquisar em " + S.me.city_name + "..." });
  search.addEventListener("input", debounce(() => { q = search.value; load(); }, 350));

  const drawChips = () => chips.replaceChildren(...[["", "Tudo"], ...Object.entries(KINDS).map(([k, v]) => [k, v.label])]
    .map(([k, l]) => h("button", { class: "chip" + (kind === k ? " on" : ""), onclick: () => { kind = k; drawChips(); load(); } }, l)));

  async function load() {
    const t = ++tick;
    list.replaceChildren(h("p", { class: "empty" }, "Carregando..."));
    const term = q.replace(/[,()%*]/g, " ").trim();
    const { data, error } = await queryPosts((sel) => {
      let qq = supabase.from("cx_posts").select(sel).eq("city_key", S.me.city_key).order("created_at", { ascending: false }).limit(60);
      if (kind) qq = qq.eq("kind", kind);
      if (term) qq = qq.or(`title.ilike.%${term}%,description.ilike.%${term}%`);
      return qq;
    });
    if (t !== tick) return;
    if (error) { list.replaceChildren(h("p", { class: "empty" }, "Não deu para carregar. Tente de novo.")); return; }
    list.replaceChildren(...(data.length ? data.map(postCard)
      : [h("p", { class: "empty" }, term || kind ? "Nada encontrado por aqui." : "Ainda não tem anúncios na sua cidade. Seja o primeiro a postar! ✨")]));
  }

  box.append(h("div", { class: "screen" },
    h("header", { class: "top" },
      h("img", { class: "mini", src: "/src/assets/icon.png", alt: "" }),
      h("div", { style: "flex:1;min-width:0" }, h("h1", {}, "City Exchange"), h("small", {}, icon("pin", 13), S.me.city_name + " · " + S.me.uf))),
    h("div", { class: "pad" }, h("div", { class: "sbox" }, icon("search", 18), search)),
    chips, list));
  drawChips();
  load();
}
