import { PERIODS, SHARE_URL, SUPABASE_URL } from "./config.js";

export const slug = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
export const money = (n) => Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const priceText = (p) => (p.kind === "doar" ? "Grátis" : money(p.price || 0) + (p.kind === "alugar" && p.rent_period ? " / " + PERIODS[p.rent_period] : ""));
export const safeUrl = (u) => (typeof u === "string" && u.startsWith(SUPABASE_URL + "/storage/") ? u : "");
export const baseUrl = () => (SHARE_URL || location.origin).replace(/\/$/, "");

export function ago(d) {
  const s = (Date.now() - new Date(d)) / 1000;
  if (s < 60) return "agora";
  if (s < 3600) return Math.floor(s / 60) + " min";
  if (s < 86400) return Math.floor(s / 3600) + " h";
  if (s < 2592000) return Math.floor(s / 86400) + " d";
  return new Date(d).toLocaleDateString("pt-BR");
}

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// Reduz a foto antes de enviar (economiza espaço e internet)
export async function compressImage(file, max = 1280) {
  const bmp = await createImageBitmap(file).catch(() => null);
  if (!bmp) return file;
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * k);
  c.height = Math.round(bmp.height * k);
  c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise((r) => c.toBlob((b) => r(b || file), "image/jpeg", 0.82));
}

export async function share(title, text, url) {
  try {
    if (navigator.share) { await navigator.share({ title, text, url }); return; }
  } catch (e) { if (e.name === "AbortError") return; }
  window.open("https://wa.me/?text=" + encodeURIComponent(text + " " + url), "_blank");
}

// Capa do vídeo: arquivo .jpg com o mesmo nome do vídeo, guardado junto no Storage
export const posterOf = (u) => String(u).replace(/\.[a-z0-9]+$/i, ".jpg");

// Tira uma foto de um quadro do vídeo (para mostrar a tela dele em vez do ícone preto)
export function videoThumb(url) {
  return new Promise((resolve) => {
    const v = document.createElement("video");
    v.muted = true; v.playsInline = true; v.preload = "auto"; v.src = url;
    let end = false;
    const done = (r) => { if (end) return; end = true; clearTimeout(t); v.removeAttribute("src"); v.load(); resolve(r); };
    const t = setTimeout(() => done(null), 9000);
    v.addEventListener("error", () => done(null));
    v.addEventListener("loadeddata", () => { try { v.currentTime = Math.min(0.5, (v.duration || 1) / 2); } catch { done(null); } });
    v.addEventListener("seeked", () => {
      try {
        if (!v.videoWidth) return done(null);
        const k = Math.min(1, 640 / Math.max(v.videoWidth, v.videoHeight));
        const c = document.createElement("canvas");
        c.width = Math.round(v.videoWidth * k); c.height = Math.round(v.videoHeight * k);
        c.getContext("2d").drawImage(v, 0, 0, c.width, c.height);
        c.toBlob((b) => done(b), "image/jpeg", 0.75);
      } catch { done(null); }
    });
  });
}
