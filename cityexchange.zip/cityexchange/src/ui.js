import { icon } from "./icons.js";
import { safeUrl } from "./utils.js";

export function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === false || v == null) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  const put = (k) => {
    if (k == null || k === false || k === true) return;
    if (Array.isArray(k)) return k.forEach(put);
    el.append(k.nodeType ? k : document.createTextNode(String(k)));
  };
  kids.forEach(put);
  return el;
}

export const go = (path) => { location.hash = "#" + path; };
export const refresh = () => window.dispatchEvent(new Event("hashchange"));
export const label = (text, el) => h("label", { class: "lb" }, h("span", {}, text), el);

export function toast(msg) {
  const t = h("div", { class: "toast" }, msg);
  document.body.append(t);
  setTimeout(() => t.remove(), 2600);
}

export function viewer(url) {
  const bg = h("div", { class: "lightbox", onclick: () => bg.remove() },
    h("img", { src: url, alt: "" }),
    h("button", { class: "ib", "aria-label": "Fechar", style: "position:absolute;right:14px;top:calc(env(safe-area-inset-top) + 14px)" }, icon("x", 20)));
  document.body.append(bg);
}

export function sheet(content) {
  const bg = h("div", { class: "sheet-bg", onclick: (e) => { if (e.target === bg) close(); } }, h("div", { class: "sheet" }, content));
  const close = () => bg.remove();
  document.body.append(bg);
  return { close };
}

export function topbar(title, { back = false, right = null } = {}) {
  return h("header", { class: "top" },
    back ? h("button", { class: "ib", "aria-label": "Voltar", onclick: () => (history.length > 1 ? history.back() : go("/feed")) }, icon("back")) : null,
    h("h1", {}, title), right);
}

export function avatar(p, size = 40, onclick) {
  const s = `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.4)}px`;
  const url = p?.avatar_url && safeUrl(p.avatar_url);
  const name = p?.name || "?";
  const hue = [...name].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  const el = url ? h("img", { class: "av", src: url, style: s, alt: "" }) : h("div", { class: "av", style: `${s};background:hsl(${hue},62%,55%)` }, name[0].toUpperCase());
  if (onclick) { el.style.cursor = "pointer"; el.addEventListener("click", onclick); }
  return el;
}

export function injectCss() {
  if (document.getElementById("cx-css")) return;
  const css = `
:root{--bg:#f4f3ff;--card:#fff;--tx:#1b1b2f;--mut:#6b6b85;--pri:#5b4bff;--pri2:#00c9a7;--line:#e4e2f5;--r:18px}
@media(prefers-color-scheme:dark){:root{--bg:#12111c;--card:#1d1c2e;--tx:#f1f0ff;--mut:#a5a3c4;--line:#2d2b45}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;height:100%;background:var(--bg);color:var(--tx);font:15px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
button,input,select,textarea{font:inherit;color:inherit}
h1,h2,h3,p{margin:0}
#app{display:flex;flex-direction:column;height:100dvh;max-width:640px;margin:0 auto;background:var(--bg)}
#view{flex:1;overflow-y:auto;overflow-x:hidden}
.screen{display:flex;flex-direction:column;min-height:100%;animation:in .25s ease}
@keyframes in{from{opacity:0;transform:translateY(8px)}}
.top{display:flex;align-items:center;gap:10px;padding:calc(env(safe-area-inset-top) + 10px) 14px 12px;background:linear-gradient(135deg,var(--pri),var(--pri2));color:#fff;position:sticky;top:0;z-index:5}
.top h1{font-size:18px;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.top small{opacity:.9;display:flex;gap:4px;align-items:center}
.mini{width:36px;height:36px;border-radius:11px}
.ib{background:rgba(255,255,255,.22);border:0;color:#fff;border-radius:12px;width:38px;height:38px;display:grid;place-items:center;cursor:pointer;flex:none}
.ib2{background:none;border:0;color:var(--mut);cursor:pointer;padding:4px}
.tabs{display:flex;background:var(--card);border-top:1px solid var(--line);padding:6px 6px calc(env(safe-area-inset-bottom) + 6px)}
.notabs .tabs{display:none}
.tab{flex:1;border:0;background:none;color:var(--mut);display:flex;flex-direction:column;align-items:center;gap:2px;font-size:11px;padding:4px;cursor:pointer}
.tab i{display:grid;place-items:center;width:46px;height:30px;border-radius:14px;font-style:normal}
.tab.on{color:var(--pri);font-weight:700}
.tab.post i{background:linear-gradient(135deg,var(--pri),var(--pri2));color:#fff}
.pad{padding:14px}.mut{color:var(--mut)}.err{color:#e5484d;font-size:13px;min-height:18px}
.sbox{display:flex;align-items:center;gap:8px;background:var(--card);border:1.5px solid var(--line);border-radius:14px;padding:0 12px;color:var(--mut)}
.sbox input{border:0;background:none;padding:12px 0;outline:none;width:100%}
.chips{display:flex;gap:8px;overflow-x:auto;padding:0 14px 4px}
.chip{white-space:nowrap;border:1.5px solid var(--line);background:var(--card);border-radius:99px;padding:7px 16px;font-weight:600;cursor:pointer}
.chip.on{background:var(--pri);border-color:var(--pri);color:#fff}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:12px 14px 20px}
.empty{grid-column:1/-1;text-align:center;color:var(--mut);padding:40px 20px}
.card{background:var(--card);border-radius:var(--r);overflow:hidden;box-shadow:0 2px 12px rgba(60,40,160,.09);cursor:pointer;transition:transform .12s}
.card:active{transform:scale(.97)}
.thumb{position:relative;aspect-ratio:1;background:var(--line)}
.thumb img{width:100%;height:100%;object-fit:cover;display:block}
.badge{position:absolute;left:8px;top:8px;color:#fff;font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px}
.vid{position:absolute;right:8px;top:8px;background:rgba(0,0,0,.55);color:#fff;border-radius:99px;padding:2px 8px;font-size:11px;display:flex;gap:4px;align-items:center}
.cbody{padding:10px}
.price{font-weight:800;color:var(--pri)}
.card h3{font-size:14px;font-weight:600;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.meta{color:var(--mut);font-size:12px;margin-top:2px}
.form{display:flex;flex-direction:column;gap:14px;padding:16px}
.lb{display:flex;flex-direction:column;gap:6px;font-weight:600;font-size:13px}
input,select,textarea{width:100%;padding:12px 14px;border:1.5px solid var(--line);border-radius:14px;background:var(--card);outline:none}
input:focus,select:focus,textarea:focus{border-color:var(--pri)}
input[type=file]{padding:9px}
.row2{display:grid;grid-template-columns:90px 1fr;gap:8px}
.btn{border:0;border-radius:14px;padding:13px 18px;background:linear-gradient(135deg,var(--pri),var(--pri2));color:#fff;font-weight:700;cursor:pointer;width:100%;display:flex;justify-content:center;align-items:center;gap:8px}
.btn.ghost{background:var(--card);color:var(--pri);border:1.5px solid var(--pri)}
.btn.red{background:#e5484d}.btn.sm{width:auto;padding:9px 16px}
.btn:disabled{opacity:.5}
.seg{display:flex;gap:8px}
.seg button{flex:1;border:1.5px solid var(--line);background:var(--card);border-radius:14px;padding:10px;font-weight:700;cursor:pointer}
.seg button.on{color:#fff;border-color:transparent}
.pvs{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.pv{position:relative;aspect-ratio:1;border-radius:12px;overflow:hidden;background:#000}
.pv img,.pv video{width:100%;height:100%;object-fit:cover}
.pv button{position:absolute;right:4px;top:4px;border:0;border-radius:50%;width:24px;height:24px;background:rgba(0,0,0,.65);color:#fff;display:grid;place-items:center;padding:0}
.cwrap{position:relative}
.carousel{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;background:#000;aspect-ratio:1}
.carousel>*{flex:0 0 100%;scroll-snap-align:center;width:100%;height:100%;object-fit:contain}
.cnt{position:absolute;right:12px;bottom:12px;background:rgba(0,0,0,.6);color:#fff;border-radius:99px;padding:2px 10px;font-size:12px}
.det{padding:16px;display:flex;flex-direction:column;gap:10px}
.det .price{font-size:24px}.det h2{font-size:20px}
.desc{white-space:pre-wrap;word-break:break-word}
.who{display:flex;align-items:center;gap:10px;background:var(--card);border-radius:var(--r);padding:10px 12px;cursor:pointer}
.who b,.who small{display:block}
.acts{display:flex;gap:8px}
.comments{padding:0 16px;display:flex;flex-direction:column;gap:12px}
.crow{display:flex;gap:10px;align-items:flex-start}.cb{flex:1;word-break:break-word}
.compose{display:flex;gap:8px;padding:8px 12px calc(env(safe-area-inset-bottom) + 8px);background:var(--card);border-top:1px solid var(--line);margin-top:auto;position:sticky;bottom:0}
.compose input{border-radius:99px}
.compose .ib{background:var(--pri);border-radius:50%}
.msgs{flex:1;overflow-y:auto;padding:10px 12px;display:flex;flex-direction:column}
.day{align-self:center;background:var(--card);color:var(--mut);font-size:11px;font-weight:700;padding:3px 12px;border-radius:99px;margin:12px 0 6px}
.mrow{display:flex;gap:6px;align-items:flex-end;margin-top:7px}
.mrow.same{margin-top:2px}.mrow.me{justify-content:flex-end}
.mrow .sp{width:30px;flex:none}
.b{max-width:78%;padding:7px 11px 5px;border-radius:16px 16px 16px 4px;background:var(--card);word-break:break-word;box-shadow:0 1px 3px rgba(60,40,160,.07)}
.b.me{background:var(--pri);color:#fff;border-radius:16px 16px 4px 16px}
.b small{display:block;font-weight:700;font-size:11px;color:var(--pri2)}
.b .t{display:block;text-align:right;font-size:10px;opacity:.6;margin-top:1px}
.mimg{display:block;width:230px;max-width:100%;max-height:300px;object-fit:cover;border-radius:12px;margin:2px 0 4px;cursor:pointer;background:var(--line)}
.cprev{display:flex;gap:8px;padding:8px 12px 0;background:var(--card);border-top:1px solid var(--line)}
.cprev .pv{width:72px;flex:none}
.composewrap{margin-top:auto;position:sticky;bottom:0;background:var(--card)}
.composewrap .compose{margin-top:0;position:static}
.compose .ib.att{background:none;color:var(--pri)}
.lightbox{position:fixed;inset:0;z-index:90;background:rgba(0,0,0,.92);display:grid;place-items:center}
.lightbox img{max-width:100%;max-height:100%;object-fit:contain}
.chatpage{display:flex;flex-direction:column;height:100%}
.row{display:flex;align-items:center;gap:12px;background:var(--card);border-radius:var(--r);padding:12px;margin:0 14px 10px;cursor:pointer}
.row .g{flex:1;min-width:0}.row .g small{display:block;color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cityrow{background:linear-gradient(135deg,var(--pri),var(--pri2));color:#fff;margin-top:14px}.cityrow small{color:#fff;opacity:.9}
.sec{font-weight:700;margin:14px 14px 8px;color:var(--mut);font-size:13px}
.phead{background:linear-gradient(135deg,var(--pri),var(--pri2));height:90px}
.pinfo{margin-top:-46px;padding:0 16px;display:flex;flex-direction:column;gap:6px;align-items:flex-start}
.pinfo .av{border:4px solid var(--bg)}
.stats{display:flex;gap:22px}.stats b{display:block;font-size:18px}
.tabs2{display:flex;margin:14px 14px 0;border-bottom:1px solid var(--line)}
.tabs2 button{flex:1;border:0;background:none;padding:10px;font-weight:700;color:var(--mut);border-bottom:3px solid transparent;cursor:pointer}
.tabs2 button.on{color:var(--pri);border-color:var(--pri)}
.supbadge{background:var(--card);border:1.5px solid var(--pri2);color:var(--pri2);border-radius:99px;padding:3px 12px;font-size:12px;font-weight:700}
.av{border-radius:50%;object-fit:cover;display:grid;place-items:center;color:#fff;font-weight:800;flex:none}
.auth{min-height:100%;display:flex;flex-direction:column;justify-content:center;padding:24px 20px;gap:14px}
.auth .logo{width:84px;height:84px;border-radius:24px;align-self:center;animation:pop .8s cubic-bezier(.2,1.4,.4,1) both}
.auth h1{text-align:center;font-size:26px;background:linear-gradient(135deg,var(--pri),var(--pri2));-webkit-background-clip:text;background-clip:text;color:transparent}
.auth .tg{text-align:center;color:var(--mut)}
.splash{position:fixed;inset:0;z-index:99;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:linear-gradient(135deg,#5b4bff,#00c9a7);color:#fff;transition:opacity .5s}
.splash.out{opacity:0}
.sp-logo{width:130px;height:130px;border-radius:30px;box-shadow:0 12px 40px rgba(0,0,0,.25);animation:pop .9s cubic-bezier(.2,1.4,.4,1) both}
.sp-name{font-size:30px;font-weight:800;animation:up .7s .5s both}.sp-tag{opacity:.9;animation:up .7s .8s both}
@keyframes pop{from{transform:scale(.2) rotate(-25deg);opacity:0}}
@keyframes up{from{transform:translateY(18px);opacity:0}}
.toast{position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#222;color:#fff;padding:10px 18px;border-radius:99px;z-index:100;animation:up .25s both;max-width:90%}
.sheet-bg{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:60;display:flex}
.sheet{background:var(--bg);width:100%;max-width:640px;margin:auto auto 0;border-radius:24px 24px 0 0;max-height:90dvh;overflow:auto;animation:up .25s both}
.pw{position:relative}.pw input{padding-right:46px}.pw .eye{position:absolute;right:6px;top:50%;transform:translateY(-50%)}
.avedit{position:relative;display:inline-block;cursor:pointer}
.avedit .cam{position:absolute;right:0;bottom:2px;width:30px;height:30px;border-radius:50%;background:var(--pri);color:#fff;display:grid;place-items:center;border:3px solid var(--bg)}
.pv.vt{background:#222}
.pl{position:absolute;inset:0;display:grid;place-items:center;color:#fff;pointer-events:none}
.pl>span{width:34px;height:34px;border-radius:50%;background:rgba(0,0,0,.55);display:grid;place-items:center;padding-left:2px}
.panel{padding:8px 0 calc(env(safe-area-inset-bottom) + 16px)}
.grab{width:42px;height:5px;border-radius:9px;background:var(--line);margin:4px auto 10px}
.pmedia{margin:0 16px;border-radius:16px;overflow:hidden;background:#000;aspect-ratio:16/10}
.pmedia img,.pmedia video{width:100%;height:100%;display:block;object-fit:cover}
.pmedia video{object-fit:contain}
.pbody{padding:12px 16px 0;display:flex;flex-direction:column;gap:10px}
.pbody h2{font-size:19px}
.clamp{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.cnts{display:flex;gap:14px;color:var(--mut);font-size:13px}.cnts span,.stat span{display:inline-flex;gap:4px;align-items:center}
.stat{display:flex;gap:10px;color:var(--mut);font-size:12px;margin-top:4px}
.acts .like{flex:none}
.btn.like.liked{background:#ff4d6d;border-color:#ff4d6d;color:#fff}
.strip{display:flex;gap:8px;overflow-x:auto;padding:10px 16px 0}
.sth{position:relative;flex:none;width:58px;height:58px;border-radius:12px;overflow:hidden;background:#222;border:2px solid transparent;padding:0;cursor:pointer}
.sth.on{border-color:var(--pri)}
.sth img{width:100%;height:100%;object-fit:cover;display:block}
.sth .pl>span{width:24px;height:24px}
`;
  document.head.append(h("style", { id: "cx-css" }, css));
}
