import { h } from "./ui.js";

export function splash(ms = 1900) {
  const el = h("div", { class: "splash" },
    h("img", { class: "sp-logo", src: "/src/assets/icon.png", alt: "" }),
    h("div", { class: "sp-name" }, "City Exchange"),
    h("div", { class: "sp-tag" }, "Vender · Alugar · Doar"));
  document.body.append(el);
  return new Promise((r) => setTimeout(() => { el.classList.add("out"); setTimeout(() => { el.remove(); r(); }, 500); }, ms));
}
