// A chave "publishable" foi feita para ficar no app. NUNCA coloque a "secret" aqui.
// Pode usar o mesmo projeto Supabase do Soninho (as tabelas daqui começam com cx_) ou criar um novo e trocar os dois valores.
export const SUPABASE_URL = "https://umvubiugozvaqmaweocw.supabase.co";
export const SUPABASE_KEY = "sb_publishable_92OWhkb6niSG8Yi9Y3HZLA_mlZJVzbP";

export const APP_NAME = "City Exchange";
export const BUCKET = "cx-media";

// Regras do anúncio (mude aqui se quiser). MIN_VIDEOS = 0 deixa o vídeo opcional.
export const MIN_PHOTOS = 2;
export const MAX_PHOTOS = 9;
export const MIN_VIDEOS = 1;
export const MAX_VIDEOS = 2;
export const MAX_VIDEO_MB = 45;

// Link do seu site (Netlify), usado no botão Compartilhar. Ex.: "https://cityexchange.netlify.app"
export const SHARE_URL = "";

export const KINDS = {
  vender: { label: "Vender", color: "#5b4bff" },
  alugar: { label: "Alugar", color: "#ff8a3d" },
  doar: { label: "Doar", color: "#00a98f" },
};
export const PERIODS = { dia: "dia", semana: "semana", mes: "mês" };
export const UFS = ["AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO"];
