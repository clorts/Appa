// Servidor local simples para testar: node serve.js  (abre em http://localhost:5173)
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { dirname, extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const dist = join(dirname(fileURLToPath(import.meta.url)), "dist");
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8" };

createServer(async (req, res) => {
  const path = normalize(decodeURIComponent(new URL(req.url, "http://x").pathname));
  const file = join(dist, path === "/" || path.includes("..") ? "index.html" : path);
  try {
    const data = await readFile(file);
    res.writeHead(200, { "Content-Type": types[extname(file)] ?? "application/octet-stream" });
    res.end(data);
  } catch {
    const data = await readFile(join(dist, "index.html"));
    res.writeHead(200, { "Content-Type": types[".html"] });
    res.end(data);
  }
}).listen(5173, "0.0.0.0", () => console.log("City Exchange em http://localhost:5173"));
