# City Exchange — a comunidade da sua cidade

JavaScript puro + Supabase + Capacitor (APK). Sem .html/.css: a página é gerada pelo `build.js` e o visual é todo em JavaScript.
Cada pessoa entra na comunidade da própria cidade: só anúncios de **vender, alugar e doar**, chat público da cidade e chat privado.

## 1) Supabase (só uma vez)
1. Abra o **SQL Editor** e rode o arquivo `supabase/001_cityexchange.sql` inteiro (pode rodar de novo sem problema).
2. **Authentication → Providers → Email**: desligue **Confirm email** (assim a pessoa entra na hora depois de criar a conta).
3. URL e chave publishable ficam em `src/config.js` (já está com o projeto novo da conta reiscauan740; para usar outro projeto, troque os dois valores). Nunca coloque a chave secret.

## 2) Gerar o APK (pelo GitHub)
1. Crie um repositório e envie este zip (ou os arquivos).
2. Aba **Actions** → "Gerar APK" → espere ficar verde (5-8 min).
3. Aba **Releases** → baixe `cityexchange.apk` e instale.

## 3) Site (Netlify)
Build command: `node build.js` — Publish directory: `dist`. Depois coloque o link em `SHARE_URL` no `src/config.js` (botão Compartilhar e Convidar amigos).

## Testar no computador
`node build.js && node serve.js` e abra http://localhost:5173

## Novidades da versão 1.1
- Corrigido o texto "null" / "[object HTMLLabelElement]" na tela de entrar/criar conta.
- Criar conta só pede e-mail, senha e cidade; o nome vem do e-mail e dá para mudar no perfil.
- Foto de perfil: toque na letra/foto no seu perfil para colocar ou trocar.
- Foto no chat público e no privado (botão de imagem ao lado da mensagem; toque na foto para abrir grande).
- Vídeo mostra um quadro dele (capa) em vez do ícone preto.
- Tocar num anúncio abre um painel embaixo; "Ver completo" mostra todos os vídeos e fotos, Entrar em contato, curtir e comentar.
- O banco novo já tem o SQL aplicado (curtidas e foto no chat). Falta só desligar "Confirm email" no Supabase e gerar o APK novo.

## O que tem
- Criar conta / entrar (nome, usuário, e-mail, senha, estado e cidade pela lista do IBGE).
- Feed da cidade com pesquisa e filtro Vender / Alugar / Doar; preço para vender e alugar (por dia, semana ou mês); doar é grátis.
- Anúncio com descrição, **2 a 9 fotos** e **1 a 2 vídeos** (regras em `src/config.js`; `MIN_VIDEOS = 0` deixa o vídeo opcional). Fotos são reduzidas antes de enviar; vídeo até 45 MB.
- Apagar o próprio anúncio (as fotos/vídeos também são apagados) e o próprio comentário (o dono do anúncio também pode apagar comentários dele).
- Comentários, compartilhar anúncio (WhatsApp etc.).
- Chat público da cidade e chat privado entre duas pessoas, em tempo real.
- Perfil seu e de outras pessoas: anúncios, foto, bio. **Apoiar** dá +1 apoiador; no perfil de quem foi apoiado aparece "fulano te apoiou".
- Ícone (`assets/icone-cityexchange.png`), banner (`assets/banner-cityexchange.png`) e animação de abertura (`src/splash.js`).

## Ainda não tem (próximos passos)
Denunciar/bloquear usuário, política de privacidade e termos, apagar a conta, notificações de mensagem, editar anúncio.
Antes de divulgar em larga escala, vale colocar denúncia e termos de uso (copie o jeito do `src/legal.js` do Soninho).
