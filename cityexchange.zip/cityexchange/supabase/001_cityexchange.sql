-- City Exchange: rode este arquivo inteiro no SQL Editor do Supabase (pode rodar de novo sem problema).

create table if not exists public.cx_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default 'Pessoa',
  username text unique not null,
  bio text default '',
  avatar_url text,
  uf text,
  city_name text,
  city_key text not null default '',
  created_at timestamptz default now()
);
create index if not exists cx_profiles_city on public.cx_profiles(city_key);

create table if not exists public.cx_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.cx_profiles(id) on delete cascade,
  city_key text not null,
  kind text not null check (kind in ('vender','alugar','doar')),
  title text not null check (char_length(title) between 3 and 80),
  description text not null check (char_length(description) between 10 and 2000),
  price numeric(12,2) check (price is null or price >= 0),
  rent_period text check (rent_period is null or rent_period in ('dia','semana','mes')),
  photos text[] not null check (cardinality(photos) between 2 and 9),
  videos text[] not null default '{}' check (cardinality(videos) <= 2),
  created_at timestamptz default now()
);
create index if not exists cx_posts_city on public.cx_posts(city_key, created_at desc);
create index if not exists cx_posts_user on public.cx_posts(user_id, created_at desc);

create table if not exists public.cx_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.cx_posts(id) on delete cascade,
  user_id uuid not null references public.cx_profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz default now()
);
create index if not exists cx_comments_post on public.cx_comments(post_id, created_at);

create table if not exists public.cx_supports (
  supporter_id uuid not null references public.cx_profiles(id) on delete cascade,
  supported_id uuid not null references public.cx_profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (supporter_id, supported_id),
  check (supporter_id <> supported_id)
);
create index if not exists cx_supports_supported on public.cx_supports(supported_id, created_at desc);

-- room: 'city:<city_key>' (chat público da cidade) ou 'dm:<id menor>:<id maior>' (privado)
create table if not exists public.cx_messages (
  id uuid primary key default gen_random_uuid(),
  room text not null,
  sender_id uuid not null references public.cx_profiles(id) on delete cascade,
  recipient_id uuid references public.cx_profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz default now()
);
create index if not exists cx_messages_room on public.cx_messages(room, created_at desc);

-- cidade de quem está logado (usada nas regras do chat público)
create or replace function public.cx_my_city() returns text
language sql stable security definer set search_path = public as
$$ select city_key from public.cx_profiles where id = auth.uid() $$;

-- cria o perfil sozinho quando a conta é criada
create or replace function public.cx_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb); base text; u text;
begin
  base := regexp_replace(lower(coalesce(nullif(m->>'username',''), split_part(new.email,'@',1))), '[^a-z0-9_.]', '', 'g');
  if length(base) < 3 then base := 'user' || substr(md5(random()::text), 1, 5); end if;
  base := left(base, 20); u := base;
  while exists (select 1 from public.cx_profiles where username = u) loop
    u := left(base, 15) || floor(random()*9000 + 1000)::int;
  end loop;
  insert into public.cx_profiles (id, name, username, uf, city_name, city_key)
  values (new.id, coalesce(nullif(m->>'name',''), 'Pessoa'), u, m->>'uf', m->>'city_name', coalesce(m->>'city_key',''));
  return new;
end $$;
drop trigger if exists cx_on_signup on auth.users;
create trigger cx_on_signup after insert on auth.users for each row execute function public.cx_new_user();

-- segurança (RLS)
alter table public.cx_profiles enable row level security;
alter table public.cx_posts enable row level security;
alter table public.cx_comments enable row level security;
alter table public.cx_supports enable row level security;
alter table public.cx_messages enable row level security;

do $$ declare r record; begin
  for r in select policyname, tablename from pg_policies where schemaname = 'public' and tablename like 'cx\_%' loop
    execute format('drop policy %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

create policy cx_prof_sel on public.cx_profiles for select to authenticated using (true);
create policy cx_prof_ins on public.cx_profiles for insert to authenticated with check (id = auth.uid());
create policy cx_prof_upd on public.cx_profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy cx_post_sel on public.cx_posts for select to authenticated using (true);
create policy cx_post_ins on public.cx_posts for insert to authenticated with check (user_id = auth.uid() and city_key = public.cx_my_city());
create policy cx_post_del on public.cx_posts for delete to authenticated using (user_id = auth.uid());

create policy cx_com_sel on public.cx_comments for select to authenticated using (true);
create policy cx_com_ins on public.cx_comments for insert to authenticated with check (user_id = auth.uid());
create policy cx_com_del on public.cx_comments for delete to authenticated using (
  user_id = auth.uid() or exists (select 1 from public.cx_posts p where p.id = post_id and p.user_id = auth.uid())
);

create policy cx_sup_sel on public.cx_supports for select to authenticated using (true);
create policy cx_sup_ins on public.cx_supports for insert to authenticated with check (supporter_id = auth.uid());
create policy cx_sup_del on public.cx_supports for delete to authenticated using (supporter_id = auth.uid());

create policy cx_msg_sel on public.cx_messages for select to authenticated using (
  (recipient_id is null and room = 'city:' || public.cx_my_city()) or sender_id = auth.uid() or recipient_id = auth.uid()
);
create policy cx_msg_ins on public.cx_messages for insert to authenticated with check (
  sender_id = auth.uid() and (
    (recipient_id is null and room = 'city:' || public.cx_my_city())
    or (recipient_id is not null and recipient_id <> sender_id
        and room = 'dm:' || least(sender_id, recipient_id)::text || ':' || greatest(sender_id, recipient_id)::text)
  )
);

-- chat em tempo real
do $$ begin
  alter publication supabase_realtime add table public.cx_messages;
exception when others then null; end $$;

-- fotos e vídeos (bucket público, 50 MB por arquivo)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('cx-media', 'cx-media', true, 52428800,
        array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime','video/webm'])
on conflict (id) do nothing;

drop policy if exists cx_media_ins on storage.objects;
drop policy if exists cx_media_del on storage.objects;
create policy cx_media_ins on storage.objects for insert to authenticated
  with check (bucket_id = 'cx-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy cx_media_del on storage.objects for delete to authenticated
  using (bucket_id = 'cx-media' and (storage.foldername(name))[1] = auth.uid()::text);
